﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;


namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        int counter = 0;
        public Window1()
        {
            InitializeComponent();
        }

        private void Btn_1_save_Click(object sender, RoutedEventArgs e)
        {
            Array.Resize(ref DataStorage.Module_code, DataStorage.Module_code.Length + 1);
            Array.Resize(ref DataStorage.Module_name, DataStorage.Module_name.Length + 1);
            Array.Resize(ref DataStorage.Module_credit, DataStorage.Module_credit.Length + 1);
            Array.Resize(ref DataStorage.Module_hoursPerWeek, DataStorage.Module_hoursPerWeek.Length + 1);

            try
            {

                DataStorage.Module_code[counter] = Convert.ToInt32(txtBx_1_code.Text);
                DataStorage.Module_name[counter] = txtBx_2_name.Text;
                DataStorage.Module_credit[counter] = Convert.ToInt32(txtBx_3_credits.Text);
                DataStorage.Module_hoursPerWeek[counter] = Convert.ToInt32(txtBx_4_hours.Text);

                counter++;

                MessageBox.Show("Data saved");
                txtBx_1_code.Clear();
                txtBx_2_name.Clear();
                txtBx_3_credits.Clear();
                txtBx_4_hours.Clear();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void Btn_2_next_Click(object sender, RoutedEventArgs e)
        {
            Window2 newForm = new Window2();
            newForm.ShowDialog();
            this.Hide();
        }
    }
}
