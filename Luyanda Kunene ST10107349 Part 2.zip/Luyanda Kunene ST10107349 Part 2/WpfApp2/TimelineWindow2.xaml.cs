﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;


namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        int count = 0;
        public Window2()
        {
            InitializeComponent();
        }

        private void Btn_2_save_Click(object sender, RoutedEventArgs e)
        {
            Array.Resize(ref DataStorage.selfStudyHours, DataStorage.selfStudyHours.Length + 1);
            try
            {

                DataStorage.weeks = Convert.ToInt32(txtBx_1_weeks.Text);
                DataStorage.semesterStart = Convert.ToDateTime(dtP_date.Text);
                DataStorage.selfStudyHours[count] = Convert.ToInt32(txtBx_2_hoursSpent.Text);
                count++;
                MessageBox.Show("Data saved");

                txtBx_2_hoursSpent.Clear();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void Btn_1_next_Click(object sender, RoutedEventArgs e)
        {
            Window3 bring = new Window3();
            bring.ShowDialog();
            this.Hide();
        }
    }
}
