﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        int count = 0;
        public Register()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-JI34J4KS\SQLEXPRESS01;Initial Catalog=Registration;Integrated Security=True");

        private void btn_Register_Click(object sender, RoutedEventArgs e)

        {
            try
            {


                
                        SqlCommand cmd = new SqlCommand("insert into [dbo].[User] values (@username, @password)", con);
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@username", username.Text);
                        cmd.Parameters.AddWithValue("@password", password.Password);
                       

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        
                        MessageBox.Show("Sucessfully Regstered to The System", "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
                        
                    

            }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                username.Clear();
                password.Clear();
                username.Text = " ";
                password.Password = "";
                MainWindow bring = new MainWindow();
                bring.ShowDialog();
                this.Hide();
            }
            
        }
    }
