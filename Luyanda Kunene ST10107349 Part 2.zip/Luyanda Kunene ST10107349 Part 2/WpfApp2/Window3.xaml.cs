﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
        }

        private void Btn_display_Click(object sender, RoutedEventArgs e)
        {
			var outcome = from temp in DataStorage.Module_code select temp;
			var outcome2 = from temp in DataStorage.Module_name select temp;
			var outcome3 = from temp in DataStorage.Module_credit select temp;
			var outcome4 = from temp in DataStorage.Module_hoursPerWeek select temp;
			var outcome5 = from temp in DataStorage.selfStudyHours select temp;

			foreach (var item in outcome)
			{
				foreach (var items in outcome2)
				{
					foreach (var items3 in outcome3)
					{
						foreach (var item4 in outcome4)
						{
							txtBlc_display.Text = "Number of weeks:" + "\t" + DataStorage.weeks + "\n" +
								"Start of semester:" + "\t" + DataStorage.semesterStart + "\n" +
								"Module code:" + "\t" + item.ToString() + "\t" + "\n" +
								"Module name:" + "\t" + items.ToString() + "\t" + "\n" +
								"Module Credit:" + "\t" + items3.ToString() + "\t" + "\n" +
								"Module hours per week" + "\t" + item4.ToString() + "\n" +
								"Self study hours :" + "\t";

						}
					}
				}
			}
		}
    }
}
