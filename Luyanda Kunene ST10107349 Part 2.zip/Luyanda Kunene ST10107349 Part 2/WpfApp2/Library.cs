﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfApp2
{
    class DataStorage
    {
        public static int[] Module_code = new int[0];
        public static string[] Module_name = new string[0];
        public static int[] Module_credit = new int[0];
        public static int[] Module_hoursPerWeek = new int[0];
        public static int weeks;
        public static DateTime semesterStart;
        public static double[] selfStudyHours = new double[0];
        public static int[] hoursLeft = new int[0];
    }
}
