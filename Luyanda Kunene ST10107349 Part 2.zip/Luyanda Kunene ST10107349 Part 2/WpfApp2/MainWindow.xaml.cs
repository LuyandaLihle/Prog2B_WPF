﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
		int counter = 0;
		public MainWindow()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-JI34J4KS\SQLEXPRESS01;Initial Catalog=Registration;Integrated Security=True");

        private void btn_Register_Click(object sender, RoutedEventArgs e)
        {
            Register bring = new Register();
            bring.ShowDialog();
            this.Hide();
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
			try
			{

                SqlDataAdapter adapter = new SqlDataAdapter("Select * from [dbo].[Login] where" +
                    " username ='" + username.Text + "'and password ='" + password.Password + "'", con);

                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                username.Clear();
                password.Clear();

                if (counter > 0)
				{

					Window1 bring = new Window1();
					bring.ShowDialog();
					this.Hide();
				}
				else
				{
					MessageBox.Show("The password or username you've entered is incorrect");
				}
			}
			catch
			{

			}
		}
    }
}
